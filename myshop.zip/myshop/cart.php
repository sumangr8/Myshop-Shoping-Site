<?php
session_start();
 include("includes/db.php");
include("functions/functions.php");
?>
<?php cart(); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/styles.css">
</head>
<body>
<div class="main_wrapper">
	<!--Header Start-->
	<div class="header_wrapper">
		<img src="images/head_logo.gif" height="100" width="300" style="float: left;">
		<img src="images/images.png" height="100" width="700" style="float: right;">
	</div>
	<!--Header End-->

	<!--Menu start-->
	<div id="navbar">
		<ul id="menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="all_products.php">All Product</a></li>
			<li><a href="my_account.php">My Account</a></li>
			<li><a href="user_register.php">Sign Up</a></li>
			<li><a href="cart.php">Shopping Cart</a></li>
			<li><a href="contact.php">Contect Us</a></li>
		</ul>
		<div id="form">
			<form method="get" accept="results.php" enctype="multipart/form-data">
				<input type="text" name="user_query" placeholder="Search a Product">
				<input type="submit" name="search" value="Search">
			</form>
		</div>
	</div>
	<!--Menu End-->

	<!--Main Content Area start-->
	<div class="content_wrapper">
		<!--Sidebar Start-->
		<div id="left_sidebar">
			<div id="sidebar_title">Category</div>
			<ul id="cats">
			  <?php getcat(); ?>
			</ul>

			<div id="sidebar_title">Brands </div>
			<ul id="cats">
				<?php getbrand(); ?>

			</ul>	
		</div>
		<!--Sidebar End-->

		<!--Content Area start-->
		<div id="right_content">
			<div id="headline">
				<div id="headline_content">
					<b>Welcome Gust</b>
					<b style="color: yellow;">Shoping Cart</b>
					<span>-Items- <?php item(); ?> Total Price  <?php total_price(); ?><a href="cart.php" style="color: yellow;">Go To Cart</a>
					
					</span>
				</div>
			</div><!--Close Headline-->

			<div id="products_box">
				
			<table width="700">
				<form method="post" action="" enctype="multipart/form-data">
					<tr>
						<td>REmove</td>
						<td>Product</td>
						<td>Quantity</td>
						<td>Total</td>
					</tr>
				<?php 
			    
					global $db;
					$ip=getRealIpAddr();
					$total=0;
					$qry=mysqli_query($db, "select * from cart where ip_add='$ip'");
					while($row=mysqli_fetch_array($qry))
					{
						extract($row);
						$qry1=mysqli_query($db,"select * from products where product_id='$p_id'");
						while($row1=mysqli_fetch_array($qry1))
						{
							extract($row1);
							$single_price=$row1["product_price"];
							$product_price=array($row1['product_price']);
							$value=array_sum($product_price);
							$total +=$value;
						?>
						<tr>
							<td><input type="checkbox" name="remove[]" value="<?php echo $p_id; ?>"></td>
							<td><?php echo $product_title;  ?></br><img src="admin_area/product_images/<?php echo $product_img1; ?>" width="80" height="80"></td>
							<td><input type="text" name="qty" value="" size="5"></td>
							<td><?php echo $single_price; ?></td>
						</tr>
						<?php
						}

				}
			 ?>
			 <tr>
			 	<td></td><td></td><td></td><td>Total Price:- $ <?php  echo $total; ?></td>
			 </tr>
			 <tr>
			 	<td><input type="submit" name="update" value="Update"></td>
			 	<td><button><a href="index.php" style="text-decoration: none; color: black;">Continue Shoping</a></button></td>
				<td><button><a href="checkout.php" style="text-decoration: none; color: black;">checkout</a></button></td>
			 </tr>
				</form>
			</table>

			<?php  
			function remove()
			{
				global $con;
				if(isset($_POST["update"]))
				{
					foreach($_POST["remove"] as $remove_id)
					{
						$qry=mysqli_query($con,"delete from cart where p_id='$remove_id'");
						if($qry)
						{
							echo "<script>window.open('cart.php','_self')</script>";
						}
					}
				}
			}
			echo @$up_cart=remove();
			?>

			</div>
		</div>
		<!--Content Area End-->

	</div>
	<!-- main Content Area End-->

	<!--Footer Start-->
	<div class="footer">
		<h1 style="color: black; padding-top: 30px; text-align: center;">@Copy; 2017- By Suman Kumar</h1>
	</div>
	<!--Footer End-->
</div>
</body>
</html>