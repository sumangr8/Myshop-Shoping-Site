<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table width="1300" border="1">
	<tr>
		<td><img src="images/images.png" width="1320" height="100"></td>
	</tr>
</table><!-- Header Close-->



<!-- Sidebar-->
<table style="background: gray; float: right; width: 250px; height: 500px; border: 1px solid black;">
	<tr>
		<td><a href="index.php?insert_product" style="text-decoration: none; color: white;">Insert New Product</a></td>
	</tr>
	<tr>
		<td><a href="index.php?view_products" style="text-decoration: none; color: white;">View Product</a></td>
	</tr>
	<tr>
		<td><a href="index.php?insert_cat" style="text-decoration: none; color: white;">Insert Category</a></td>
	</tr>
	<tr>
		<td><a href="index.php?view_cat" style="text-decoration: none; color: white;">View All Category</a></td>
	</tr>
	<tr>
		<td><a href="index.php?insert_brand" style="text-decoration: none; color: white;">Insert New Brand</a></td>
	</tr>

	<tr>
		<td><a href="index.php?view_brand" style="text-decoration: none; color: white;">View All Brand</a></td>
	</tr>
	<tr>
		<td><a href="index.php?view_customers" style="text-decoration: none; color: white;">View customer</a></td>
	</tr>
	<tr>
		<td><a href="index.php?view_order" style="text-decoration: none; color: white;">view Order</a></td>
	</tr>
	<tr>
		<td><a href="index.php?view_payments" style="text-decoration: none; color: white;">view Payments</a></td>
	</tr>
	<tr>
		<td><a href="logout.php" style="text-decoration: none; color: white;">Logout</a></td>
	</tr>
</table>



<table style="background-color: brown; width: 80%; height: 500px; float: left;">
	<tr>
	<td>
		<?php
			include("includes/db.php");
			if(isset($_GET["insert_product"]))
			{
				include("insert_product.php");
			}

			if(isset($_GET["view_products"]))
			{
				include("view_products.php");
			}

			if(isset($_GET["edit_pro"]))
			{
				include("edit_pro.php");
			}

			if(isset($_GET["insert_cat"]))
			{
				include("insert_cat.php");
			}

			if(isset($_GET["view_cat"]))
			{
				include("view_cat.php");
			}
			if(isset($_GET["edit_cat"]))
			{
				include("edit_cat.php");
			}

			if(isset($_GET["delete_cat"]))
			{
				include("delete_cat.php");
			}

			if(isset($_GET["insert_brand"]))
			{
				include("insert_brand.php");
			}
			if(isset($_GET["view_brand"]))
			{
				include("view_brand.php");
			}

			if(isset($_GET["edit_brand"]))
			{
				include("edit_brand.php");
			}
			if(isset($_GET["delete_brand"]))
			{
				include("delete_brand.php");
			}




		?>
	</td>
	</tr>
</table>
</body>
</html>