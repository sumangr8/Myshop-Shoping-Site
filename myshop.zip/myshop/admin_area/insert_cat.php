<?php

$db=mysqli_connect("localhost","root","","myshop");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table>
	<form method="post" action="">
		<tr>
			<td>Insert Category</td>
			<td><input type="text" name="cat_title"></td>
			<td><input type="submit" name="insert" value="Insert"></td>
		</tr>

	</form>
</table>
<?php
	if(isset($_POST["insert"]))
	{
		extract($_POST);
		$qry=mysqli_query($db,"insert into categories (cat_title) values ('$cat_title')");
	}

?>
</body>
</html>