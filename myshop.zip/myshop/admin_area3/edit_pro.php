<?php
$con=mysqli_connect("localhost","root","","myshop");
if(isset($_GET['edit_pro']))
{
	extract($_GET);
	$qry=mysqli_query($con,"select * from products where product_id='$edit_pro'");
	$row=mysqli_fetch_array($qry);
	extract($row);
}

//For Category
$qry_cat=mysqli_query($con,"select * from categories where cat_id='$cat_id'");
$cat_row=mysqli_fetch_array($qry_cat);
extract($cat_row);

//For Brand
$qry_brand=mysqli_query($con,"select * from brands where brand_id='$brand_id'");
$brand_row=mysqli_fetch_array($qry_brand);
extract($brand_row);
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table align="center">
<h3 style="margin-left: 400px;">Update Product.....</h3>
	<form method="post" action="" enctype="multipart/form-data">
		<tr>
			<td>Product Title</td>
			<td><input type="text" name="product_title" value="<?php echo $product_title; ?>"></td>
		</tr>
		<tr><td>Product Category</td>
		<td>
		<select name="product_cat">
			<option value="<?php echo $cat_id; ?>"><?php echo $cat_title; ?></option>
			<?php
				$qry=mysqli_query($db,"select * from categories");
				while($row_cat=mysqli_fetch_array($qry))
				{
					extract($row_cat);
					echo "<option value='$cat_id'>$cat_title</option>";
				}
			?>
		</select>
		</td>
		</tr>
		<tr>
			<td>Product Brand</td>
			<td>
				<select name="product_brand">
					<option value="<?php echo $brand_id; ?>"><?php echo $brand_title; ?></option>
					<?php
					$qry1=mysqli_query($db,"select * from brands");
					while($row_brand=mysqli_fetch_array($qry1))
					{
						extract($row_brand);
						echo "<option value='$brand_id'>$brand_title</option>";
					}
					?>
				</select>
			</td>
		</tr>

		<!-- <tr>
			<td>Image1</td>
			<td><input type="file" name="product_img1"><br><img src="product_images/<?php echo $product_img1; ?>" width='80' height='80'></td>
		</tr>
		<tr>
			<td>Image2</td>
			<td><input type="file" name="product_img2"><br><img src="product_images/<?php echo $product_img2; ?>" width='80' height='80'></td>
		</tr>
		<tr>
			<td>Image3</td>
			<td><input type="file" name="product_img3"><br><img src="product_images/<?php echo $product_img3; ?>" width='80' height='80'></td>
		</tr> -->
		<tr>
			<td>Product Price</td>
			<td><input type="text" name="product_price" value="<?php echo $product_price; ?>"></td>
		</tr>
		<tr>
			<td>Product Description</td>
			<td><input type="text" name="product_desc" value="<?php echo $product_desc; ?>"></td>
		</tr>
		<tr>
			<td>Product Keyword</td>
			<td><input type="text" name="product_keywords" value="<?php echo $product_keywords; ?>"></td>
		</tr>
		<tr>
			<td><input type="submit" name="e" value="Update Product"></td>
		</tr>
	</form>
</table>
<?php
if(isset($_POST["e"]))
{
	$product_title=$_POST["product_title"];
	$cat_id=$_POST["product_cat"];
	$brand_id=$_POST["product_brand"];
	$product_price=$_POST["product_price"];
	$product_desc=$_POST["product_desc"];
	$product_keywords=$_POST["product_keywords"];
	$status='on';
	// $product_img1=$_FILES["product_img1"]["name"];
	// $product_img2=$_FILES["product_img2"]["name"];
	// $product_img3=$_FILES["product_img3"]["name"];

	// $temp_name1=$_FILES["product_img1"]["tmp_name"];
	// $temp_name2=$_FILES["product_img2"]["tmp_name"];
	// $temp_name3=$_FILES["product_img3"]["tmp_name"];

	// move_uploaded_file($product_img1, "product_images/$product_img1");
	// move_uploaded_file($product_img2, "product_images/$product_img2");
	// move_uploaded_file($product_img3, "product_images/$product_img3");

	$qry2=mysqli_query($db,"update products set product_title='$product_title',cat_id='$cat_id',brand_id='$brand_id',product_price='$product_price',product_desc='$product_desc',product_keywords='$product_keywords',status='$status' where product_id='$edit_pro'");
	if($qry2)
	{
		echo "<script>window.open('index.php?view_products','_self')</script>";
	}
	
}
?>
</body>
</html>