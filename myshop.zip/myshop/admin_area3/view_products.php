<?php
$con=mysqli_connect("localhost","root","","myshop");

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table align="center" width="900">
	<tr>
		<th>Product Id</th>
		<th>Title</th>
		<th>Image</th>
		<th>Price</th>
		<th>Total Sold</th>
		<th>Status</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<tr>
	<?php
	$i=1;
	$qry=mysqli_query($con,"select * from products");
	while($row=mysqli_fetch_array($qry))
	{
		extract($row);
	?>
<tr align="center">
	<td><?php echo $i;  ?></td>
	<td><?php echo $product_title;  ?></td>
	<td><img src="product_images/<?php echo $product_img1; ?>" width="80" height="80"></td>
	<td><?php echo $product_price;  ?></td>
	<td></td>
	<td><?php echo $status;  ?></td>
	<td><a href="index.php?edit_pro=<?php  echo $product_id; ?>">Edit</a></td>
	<td><a href="delete_pro.php?delete_pro=<?php  echo $product_id; ?>">Delete</td>
</tr>
	
	<?php
	$i++;
	}
	?>
	</tr>
</table>
</body>
</html>